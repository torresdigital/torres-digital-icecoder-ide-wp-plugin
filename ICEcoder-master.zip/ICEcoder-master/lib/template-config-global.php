<?php
/*

a:9:{s:13:"loginRequired";b:1;s:18:"enableRegistration";b:1;s:9:"multiUser";b:0;s:8:"demoMode";b:0;s:11:"newDirPerms";i:755;s:12:"newFilePerms";i:644;s:16:"fileDirResOutput";s:4:"none";s:10:"lineEnding";s:1:"
";s:12:"languageBase";s:11:"english.php";}

*/
?>
