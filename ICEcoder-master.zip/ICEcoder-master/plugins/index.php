<?php
header("Location: ../");
exit;
