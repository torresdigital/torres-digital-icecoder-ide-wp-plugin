<?php
header("Location: ../");
die();
